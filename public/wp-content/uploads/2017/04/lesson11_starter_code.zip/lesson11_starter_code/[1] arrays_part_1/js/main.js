
// -------------------------------------------------------------------------------
// Part 1 - Compare two numbers! (use the cheat sheet for reference)
// -------------------------------------------------------------------------------

// 1. Declare a variable called "groceries" and assign it an array of strings: "milk", "eggs", "salmon", "asparagus"


// 2. Add a fifth item to the array: "apples"


// 3. Replace the second item in the array. The new value should be "brussel sprouts"


// 4. Add a sixth item to the array: "oranges"


// Use console.log *everywhere* along the way to make sure things are working!
// console.log(groceries.length);
