groceries.forEach(function(element, index){
    $('ul').append('<li>' + element + '</li>');
});
