var carousel = ['images/image_1.jpg', 'images/image_2.jpg', 'images/image_3.jpg', 
'images/image_4.jpg', 'images/image_5.jpg', 'images/image_6.jpg'];


carousel.forEach(function(element, index){

	console.log (element, index);

})
$(function () {
    $('.slideshow').each(function () {
        // Instance of slideshow
        var $slideshow = $(this);
        // Set count of images in slideshow
        $slideshow.find('img').length;
        // Hide all but first image
        $slideshow.find('img').not(':first').hide(0);
        // Store the current image as data on the slideshow
        $slideshow.data('data-image', 0);
    });

    $('#next').click(function (e) {
        // Find the parent slideshow
        var $slideshow = $(this).closest('.slideshow');
        // Get the images of that slideshow
        var $images = $slideshow.find('img');
        // Get current image from data - could also get from visibility of image
        var currentImage = $slideshow.data('data-image');
        // Get count of images
        var imagesCounter = $images.length;
        // Hide the current image
        $images.eq(currentImage).hide(0);
        // Increase the counter and wrap at the end
        currentImage = currentImage >= imagesCounter - 1 ? 0 : currentImage + 1;
        // Save the current image number
        $slideshow.data('data-image', currentImage);
        // Show the new image
        $images.eq(currentImage).show(0);
        // Set the text to match the count
      
        // Set the text to match the description in the image
      
    });
});

var currentPosition = 0;

$("#next").on("click", function(){
    $("#image-to-vote-on").attr("src", carousel[currentPosition++]);
console.log(currentPosition);
});

/*
$("#Previous").on("click", function(){
    $("#image-to-vote-on").attr("src", carousel[currentPosition--]);
console.log(currentPosition);
});

*/









