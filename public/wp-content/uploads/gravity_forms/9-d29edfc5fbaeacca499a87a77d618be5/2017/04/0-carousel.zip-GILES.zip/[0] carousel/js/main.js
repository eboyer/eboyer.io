//VARIABLES

var likes = [0,0,0,0,0,0];

//2) Declare a variable the array of images (refer to in-class lanb on Monday)
var images = ['images/image_1.jpg', 'images/image_2.jpg', 'images/image_3.jpg', 'images/image_4.jpg', 'images/image_5.jpg', 'images/image_6.jpg'];
console.log(images);

var currentPosition = 0;

//PREVIOUS, NEXT & VOTING CLICKS

//3) Make "on Click" event on "Next" button to...
$("#next").on("click", function(){
	currentPosition++;
	$("#image-to-vote-on").attr("src", images[currentPosition]);
console.log(currentPosition);
	$("#votes").html("Likes: " + likes[currentPosition]);

buttonDisable();
});

$("#prev").on("click", function(){
	$("#image-to-vote-on").attr("src", images[currentPosition--]);
console.log(currentPosition);
	$("#votes").html("Likes: " + likes[currentPosition]);

buttonDisable();
});

$("#upvote").on("click", function(){
	likes[currentPosition]++;
	console.log(likes);
	$("#votes").html("Likes: " + likes[currentPosition]);

});
//Disable "Disable" button (Make "False")

//Re-enable "Disabled" button at beginning and end of array (Restore "True")

//FUNCTIONS

function buttonDisable () {

if (currentPosition === 5){
	$("button#next").prop("disabled", true);
}

else{
	$("button#next").prop("disabled", false);
}

if (currentPosition === 0){
	$("button#prev").prop("disabled", true);
}

else{
	$("button#prev").prop("disabled", false);
}
}



//Is this a place for an array inside of an array?

//CAROUSEL
//- Figure out where we currently are in the array
//-- Compare where we are currently?  Maintain where we are the whole time?
//- Determine what's next in the array
//- Replace the html attribute on the page with the value of array
//- If where we currently are is array.length-2 then disable the next button


//4) Make "on Click" event on "Previous" button to...
//- Figure out where we currently are in the array
//-- Compare where we are currently?  Maintain where we are the whole time?
//- Determine what's previous in the array
//- Replace the html attribute on the page with the value of array
//- If where we currently are is array[1] then disable  Remove "Disable"?

//* Add the ability for user to remove their like.  Remove the disable?



//var =  the previous button

//LIKES
//5) Make "onClick" event on the thumbs up button
//- Add 1 to whatever the current total of the like variable is

//6) Make "onClick" event on the thumbs down button
//- Subtract 1 from whatever the current total of the like variable is

//* Add user validation after testing to make sure they can only click once.



//function
 


//var = [images];