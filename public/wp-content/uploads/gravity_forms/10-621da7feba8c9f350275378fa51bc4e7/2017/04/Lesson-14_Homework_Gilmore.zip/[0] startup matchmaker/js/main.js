$(".js-hamburger").on("click", function (event){
	event.preventDefault();
$(".js-navigation").toggle();


});
