console.log('hi');

$('.js-hamburger').on('click', function(event){
	event.preventDefault();
	$('.js-navigation').toggle();
	console.log('hi');
});